# Maya glyph blocks detection > 2026-02-02 7:51pm
https://universe.roboflow.com/my-workspace-hn9pt/maya-glyph-blocks-detection-4bgs7

Provided by a Roboflow user
License: CC BY 4.0

This project uses cutting-edge computer vision (YOLOv8) to detect glyph blocks in ancient Maya inscriptions — the foundational step in building AI systems that can read, interpret, and help preserve Maya writing.

**🔍 What it does**

The model is trained to automatically locate and outline glyph blocks in line drawings and monument images. These blocks are the structural units of Maya script — where complex signs, meaning, and history come together. This tool enables downstream tasks like:
	•	Glyph classification
	•	Reading order analysis
	•	Automated translation attempts
	•	Visual search through the Maya corpus

**🧠 Why it matters**

The Maya script is one of the most visually complex and beautiful writing systems on Earth. As a descendant of the Maya people, I believe that one of the greatest tragedies is the erasure of our memory — not only through colonization, but through silence.

This project is a step toward using AI to reverse that silence.

By making Maya writing more accessible to scholars, educators, and above all young Maya people, we are not just analyzing data — we are reclaiming a voice.

We are building tools that can protect, preserve, and reactivate a millennia-old legacy.

This isn’t just AI. This is cultural resistance — powered by code and technology.

**Collboration**

Find me on x: @BenjaminRosell